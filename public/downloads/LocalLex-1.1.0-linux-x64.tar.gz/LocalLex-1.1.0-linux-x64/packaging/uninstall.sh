#!/usr/bin/env bash
#
# Gỡ LocalLex khỏi menu ứng dụng. Chỉ xoá desktop entry và icon đã cài —
# không đụng tới bundle của app lẫn dữ liệu người dùng.
set -euo pipefail

app_id="com.tdson.LocalLex"
data_dir="${XDG_DATA_HOME:-$HOME/.local/share}"
thu_muc_icon="$data_dir/icons/hicolor"
thu_muc_desktop="$data_dir/applications"

rm -f "$thu_muc_desktop/$app_id.desktop"
rm -f "$thu_muc_icon"/*/apps/"$app_id.png"

command -v update-desktop-database >/dev/null 2>&1 &&
  update-desktop-database "$thu_muc_desktop" || true
command -v gtk-update-icon-cache >/dev/null 2>&1 &&
  gtk-update-icon-cache -f -t "$thu_muc_icon" >/dev/null 2>&1 || true

echo "Đã gỡ LocalLex khỏi menu ứng dụng (bundle và dữ liệu vẫn còn)."
