#!/usr/bin/env bash
#
# Cài LocalLex vào menu ứng dụng của người dùng hiện tại.
#
#   ./install.sh [đường-dẫn-tới-bundle]
#
# Không cần quyền root: mọi thứ nằm dưới ~/.local/share. Bản thân app không bị
# chép đi đâu cả — desktop entry chỉ trỏ tới bundle đang nằm sẵn trên đĩa, nên
# đừng xoá hay đổi tên thư mục bundle sau khi cài.
set -euo pipefail

goc_script="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Bundle nằm ở đâu: đối số dòng lệnh, rồi ngay cạnh script (khi phân phối thì
# packaging/ và bundle/ được chép cùng nhau), rồi thư mục build trong repo.
if [[ $# -ge 1 ]]; then
  bundle="$1"
elif [[ -x "$goc_script/../bundle/locallex" ]]; then
  bundle="$goc_script/../bundle"
else
  bundle="$goc_script/../../build/linux/x64/release/bundle"
fi

if [[ ! -x "$bundle/locallex" ]]; then
  echo "Không thấy thực thi tại '$bundle/locallex'." >&2
  echo "Chạy 'flutter build linux --release' trước, hoặc truyền đường dẫn bundle:" >&2
  echo "  $0 /duong/dan/toi/bundle" >&2
  exit 1
fi
bundle="$(cd "$bundle" && pwd)"

app_id="com.tdson.LocalLex"
data_dir="${XDG_DATA_HOME:-$HOME/.local/share}"
thu_muc_icon="$data_dir/icons/hicolor"
thu_muc_desktop="$data_dir/applications"

# Icon cho mọi cỡ mà theme hicolor định nghĩa.
for nguon in "$goc_script/icons/hicolor"/*/apps/"$app_id.png"; do
  co="$(basename "$(dirname "$(dirname "$nguon")")")"
  install -Dm644 "$nguon" "$thu_muc_icon/$co/apps/$app_id.png"
done

# Desktop entry, với đường dẫn thực thi điền vào chỗ @EXEC@. Dấu ngoặc kép chỉ
# thêm khi cần, để Exec= dễ đọc trong trường hợp thường.
exec_field="$bundle/locallex"
[[ "$exec_field" == *[[:space:]]* ]] && exec_field="\"$exec_field\""

mkdir -p "$thu_muc_desktop"
dich="$thu_muc_desktop/$app_id.desktop"
mau="$(cat "$goc_script/$app_id.desktop")"
printf '%s\n' "${mau//@EXEC@/$exec_field}" > "$dich"
chmod 644 "$dich"

if command -v desktop-file-validate >/dev/null 2>&1; then
  desktop-file-validate "$dich"
fi

# Làm mới cache, nếu thiếu công cụ thì bỏ qua — icon vẫn hiện ra sau khi đăng
# nhập lại, chỉ là không hiện ngay.
command -v update-desktop-database >/dev/null 2>&1 &&
  update-desktop-database "$thu_muc_desktop" || true
command -v gtk-update-icon-cache >/dev/null 2>&1 &&
  gtk-update-icon-cache -f -t "$thu_muc_icon" >/dev/null 2>&1 || true

echo "Đã cài LocalLex vào menu ứng dụng."
echo "  bundle:  $bundle"
echo "  entry:   $dich"
echo "Gỡ bằng: $goc_script/uninstall.sh"
