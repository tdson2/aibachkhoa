@echo off
rem Mo BKSafe bang quyen quan tri.
rem
rem Can cho: don rac cua he thong, dung/tat dich vu, va dem byte mang theo tung tien trinh.
rem Dung ban thuong (bksafe.exe) cho viec xem hang ngay cung du.
powershell -NoProfile -Command "Start-Process -FilePath '%~dp0bksafe.exe' -Verb RunAs"
